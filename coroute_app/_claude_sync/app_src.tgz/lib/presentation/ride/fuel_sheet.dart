import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/ui/ui.dart';
import '../../domain/safety/fuel_profile.dart';
import '../../data/services/settings_service.dart';
import '../../data/services/safety_service.dart';

Future<void> showFuelSheet(BuildContext context, {bool configure = false}) =>
    showAppSheet<void>(
      context,
      title: 'Fuel',
      isScrollControlled: true,
      builder: (_) => _FuelSheet(
        settings: context.read<SettingsService>(),
        safety: context.read<SafetyService?>(),
        configure: configure,
      ),
    );

class _FuelSheet extends StatefulWidget {
  final SettingsService settings;
  final SafetyService? safety;
  final bool configure;
  const _FuelSheet({
    required this.settings,
    required this.safety,
    required this.configure,
  });
  @override
  State<_FuelSheet> createState() => _FuelSheetState();
}

class _FuelSheetState extends State<_FuelSheet> {
  late bool editing, litres;
  late final TextEditingController capacity, mileage, range, margin;
  final amount = TextEditingController();
  String action = 'left';
  String? error;
  bool saving = false;

  String number(double n) =>
      n == n.roundToDouble() ? n.toInt().toString() : n.toStringAsFixed(1);
  @override
  void initState() {
    super.initState();
    final p = widget.settings.fuelProfile;
    editing = widget.configure || !p.valid;
    litres = p.litresMode;
    capacity = TextEditingController(
      text: p.capacityL > 0 ? number(p.capacityL) : '',
    );
    mileage = TextEditingController(
      text: p.mileageKmL > 0 ? number(p.mileageKmL) : '',
    );
    range = TextEditingController(text: p.rangeKm > 0 ? number(p.rangeKm) : '');
    margin = TextEditingController(text: number(p.marginKm));
  }

  @override
  void dispose() {
    for (final c in [capacity, mileage, range, margin, amount]) {
      c.dispose();
    }
    super.dispose();
  }

  double n(TextEditingController c) =>
      double.tryParse(c.text.trim().replaceAll(',', '.')) ?? double.nan;
  Widget field(
    String label,
    TextEditingController c, {
    String? help,
    String? hint,
  }) => Padding(
    padding: const EdgeInsets.only(bottom: Space.s12),
    child: TextField(
      controller: c,
      enabled: !saving,
      keyboardType: const TextInputType.numberWithOptions(decimal: true),
      decoration: InputDecoration(
        labelText: label,
        helperText: help,
        helperMaxLines: 3,
        hintText: hint,
      ),
    ),
  );

  Future<void> saveSetup() async {
    final distance = litres ? n(capacity) * n(mileage) : n(range);
    final early = n(margin);
    if (!distance.isFinite || distance <= 0 || (!litres && distance > 3000)) {
      setState(
        () => error = litres
            ? 'Enter your tank size and mileage.'
            : 'Enter a full-tank distance between 1 and 3000 km.',
      );
      return;
    }
    if (!early.isFinite || early < 0 || early >= distance) {
      setState(
        () => error =
            'The safety margin must be smaller than your full-tank distance.',
      );
      return;
    }
    final buffer = early.clamp(0, 500).toDouble();
    final extra = early - buffer;
    final next = FuelProfile(
      capacityL: litres ? n(capacity) : 0,
      mileageKmL: litres ? n(mileage) : 0,
      fullRangeKm: litres ? 0 : distance,
      reserveL: litres ? extra / n(mileage) : 0,
      reserveKm: litres ? 0 : extra,
      bufferKm: buffer,
    );
    if (!next.valid) {
      setState(
        () => error =
            'Check tank size (up to 100 L) and mileage (up to 150 km/L).',
      );
      return;
    }
    setState(() {
      saving = true;
      error = null;
    });
    try {
      await widget.settings.setFuelProfile(next);
      if (mounted) {
        setState(() {
          editing = false;
          amount.clear();
          action = 'left';
        });
      }
    } catch (_) {
      if (mounted) setState(() => error = 'Could not save. Please try again.');
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  Future<void> confirm({bool full = false}) async {
    final safety = widget.safety;
    if (safety?.fuelTrackingActive != true) return;
    final p = widget.settings.fuelProfile;
    final value = n(amount);
    final added = action == 'added';
    if (!full &&
        (!value.isFinite ||
            value < 0 ||
            (added && value == 0) ||
            value > (p.litresMode ? p.capacityL : p.rangeKm))) {
      setState(
        () => error =
            'Enter ${added ? 'more than 0 and ' : ''}up to ${number(p.litresMode ? p.capacityL : p.rangeKm)} ${p.litresMode ? 'litres' : 'km'}.',
      );
      return;
    }
    final ok = safety!.refuel(
      full: full,
      addedL: !full && added ? value : null,
      currentL: !full && !added && p.litresMode ? value : null,
      currentKm: !full && !added && !p.litresMode ? value : null,
    );
    if (ok) {
      setState(() { saving = true; error = null; });
      final saved = await safety.waitForFuelSave();
      if (!mounted) return;
      if (saved) { Navigator.pop(context); }
      else { setState(() { saving = false; error = 'Fuel updated, but could not be saved. Try again before closing.'; }); }
    } else {
      setState(
        () => error = 'The previous estimate is missing or out of date. Choose Fuel left instead.',
      );
    }
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
    listenable: Listenable.merge([
      widget.settings,
      if (widget.safety != null) widget.safety!,
    ]),
    builder: (context, _) {
      final p = widget.settings.fuelProfile;
      final safety = widget.safety;
      final estimate = safety?.estimatedUsableKm;
      final active = safety?.fuelTrackingActive == true;
      final uncertain = safety?.fuelEstimateUncertain == true;
      return ListView(
        shrinkWrap: true,
        children: [
          if (error != null)
            Padding(
              padding: const EdgeInsets.only(bottom: Space.s12),
              child: Text(
                error!,
                style: AppText.label.copyWith(color: StatusColors.warning),
              ),
            ),
          if (editing) ...[
            Text('How far does a full tank take you?', style: AppText.title),
            const SizedBox(height: Space.s8),
            const Text('Use your usual distance. You can change it later.'),
            const SizedBox(height: Space.s16),
            if (!litres)
              field('Full tank distance (km)', range, hint: 'For example, 300'),
            SwitchListTile(
              key: const ValueKey('fuelLitresMode'),
              contentPadding: EdgeInsets.zero,
              title: const Text('Use tank size and mileage instead'),
              value: litres,
              onChanged: saving
                  ? null
                  : (v) => setState(() {
                      litres = v;
                      error = null;
                    }),
            ),
            if (litres) ...[
              field('Tank size (litres)', capacity, hint: 'For example, 12'),
              field('Mileage (km per litre)', mileage, hint: 'For example, 30'),
            ],
            ExpansionTile(
              tilePadding: EdgeInsets.zero,
              title: const Text('Safety margin'),
              subtitle: Text('${margin.text} km kept aside'),
              children: [
                field(
                  'Keep aside (km)',
                  margin,
                  help: 'We subtract this once from your estimate, so you can plan an earlier stop.',
                ),
              ],
            ),
            const SizedBox(height: Space.s12),
            FilledButton(
              onPressed: saving ? null : saveSetup,
              child: Text(saving ? 'Saving...' : 'Save and continue'),
            ),
            if (p.valid)
              TextButton(
                onPressed: saving
                    ? null
                    : () => setState(() {
                        editing = false;
                        error = null;
                      }),
                child: const Text('Cancel'),
              ),
          ] else ...[
            Text(
              !active
                  ? 'Fuel setup saved'
                  : uncertain
                  ? 'Update your fuel estimate'
                  : estimate == null
                  ? 'How much fuel is left?'
                  : 'About ${estimate.floor()} km before refuelling',
              style: AppText.title,
            ),
            const SizedBox(height: Space.s8),
            Text(
              !active
                  ? 'Start a ride to track fuel. Then tell us if the tank is full or partly filled.'
                  : uncertain
                  ? 'Some riding distance was missed. Enter the fuel left to start again.'
                  : 'An estimate, not a fuel gauge. ${number(p.marginKm)} km is already kept aside.',
            ),
            const SizedBox(height: Space.s16),
            if (active) ...[
              FilledButton(
                onPressed: saving ? null : () => confirm(full: true),
                child: const Text('I filled the tank completely'),
              ),
              const SizedBox(height: Space.s16),
              if (p.litresMode)
                Wrap(
                  spacing: Space.s8,
                  children: [
                    ChoiceChip(
                      label: const Text('Fuel left'),
                      selected: action == 'left',
                      onSelected: (_) => setState(() {
                        action = 'left';
                        amount.clear();
                        error = null;
                      }),
                    ),
                    ChoiceChip(
                      label: const Text('Fuel added'),
                      selected: action == 'added',
                      onSelected: estimate == null || uncertain
                          ? null
                          : (_) => setState(() {
                              action = 'added';
                              amount.clear();
                              error = null;
                            }),
                    ),
                  ],
                ),
              field(
                p.litresMode
                    ? (action == 'added'
                          ? 'Litres added at the pump'
                          : 'Litres left in the tank')
                    : 'Distance left on your bike (km)',
                amount,
                help: p.litresMode
                    ? null
                    : 'Enter the bike display or your own estimate. We will keep ${number(p.marginKm)} km aside.',
              ),
              OutlinedButton(
                onPressed: saving ? null : () => confirm(),
                child: Text(
                  action == 'added' ? 'Add this fuel' : 'Update fuel left',
                ),
              ),
            ],
            TextButton(
              onPressed: saving ? null : () => setState(() {
                editing = true;
                error = null;
              }),
              child: const Text('Change fuel setup'),
            ),
            if (!active)
              FilledButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Done'),
              ),
          ],
          const SizedBox(height: Space.s12),
          SwitchListTile(
            key: const ValueKey('shareFuelEstimate'),
            contentPadding: EdgeInsets.zero,
            title: const Text('Share range with my group'),
            subtitle: const Text(
              'Optional. Shares kilometres left, not tank size or mileage.',
            ),
            value: widget.settings.shareFuelEstimate,
            onChanged: saving
                ? null
                : (value) async {
                    setState(() {
                      saving = true;
                      error = null;
                    });
                    try {
                      await widget.settings.setShareFuelEstimate(value);
                    } catch (_) {
                      if (mounted) {
                        setState(
                          () => error = 'Could not save sharing. Try again.',
                        );
                      }
                    } finally {
                      if (mounted) setState(() => saving = false);
                    }
                  },
          ),
          if (safety?.fuelSaveFailed == true)
            Text(
              'This estimate has not been saved. Keep the app open and update fuel again.',
              style: AppText.label,
            ),
        ],
      );
    },
  );
}
